package PROJETO_FAZENDAA;

public class gerente extends funcionario{

    public gerente(String nome, String CPF, int idade, double adicional){
        super(nome, CPF, idade, adicional);
    }
}
